import os

os.system("service apache2 restart")
