import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper

def check(path):
	print ''
	print ' Allow Appropriate Access to Web Content '.center(85, '#')
	print ''
	result = helper.read_file(path)
	obj = re.compile(r'[^#]<Directory \/>(?:.*?)<\/Directory>',re.DOTALL).findall(result)
	if len(obj) != 1:
		print '[WARNING] Number of DocumentRoot in apache config more than one'
	print '[NOTICE] Ensure that the Order/Deny/Allow directives are NOT used for the all directory'
	print '[NOTICE] Ensure the Require directives have values that are appropriate for the purposes of the directory'

