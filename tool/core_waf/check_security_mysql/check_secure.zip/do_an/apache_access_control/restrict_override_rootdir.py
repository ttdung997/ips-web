import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper



def check(path):
	print ''
	print ' Restrict Override for the OS Root Directory '.center(85, '#')
	print ''
	result = helper.read_file(path)
	obj = re.compile(r'[^#]<Directory \/>(.*?)<\/Directory>',re.DOTALL).findall(result)
	if len(obj) != 0:
		if obj[0].find('AllowOverride ') == -1:
			print '[WARNING] AllowOverride directive is not exist in root directory'
		else:
			obj1 = re.compile(r'^\s*AllowOverride (.*?)\n',re.MULTILINE).findall(obj[0])
			if obj1[0] != 'None':
				print '[WARNING] Value of AllowOverride is not set to None in root directory'
		if obj[0].find('AllowOverrideList') != -1:
			print '[WARNING] AllowOverrideList is exist in root directory'
	else:
		print '[WARNING] RootDirectory is not exist'
	

def add_allowoverride(path):
	result = helper.read_file(path)
	obj = re.compile(r'<Directory \/>(.*?)<\/Directory>',re.DOTALL).findall(result)
	replace = obj[0] + '\tAllowOverride None\n'
	replace1 = re.sub(r'<Directory \/>(.*?)<\/Directory>','\n<Directory />'+replace+'</Directory>',result, flags=re.DOTALL)
	helper.write_file(path, replace1)

def remove_allowoverridelist(path):
	result = helper.read_file(path)
	obj = re.compile(r'<Directory \/>(.*?)<\/Directory>',re.DOTALL).findall(result)
	replace = re.sub(r'^\s*AllowOverrideList (?:.*?)\n','\n',obj[0],flags=re.MULTILINE)
	replace1 = re.sub(r'<Directory \/>(.*?)<\/Directory>','\n<Directory />'+replace+'</Directory>',result, flags=re.DOTALL)
	helper.write_file(path, replace1)

def set_allowoverride(path):
	result = helper.read_file(path)
	obj = re.compile(r'<Directory \/>(.*?)<\/Directory>',re.DOTALL).findall(result)
	replace = re.sub(r'^\s*AllowOverride (?:.*?)\n','\tAllowOverride None\n',obj[0],flags=re.MULTILINE)
	replace1 = re.sub(r'<Directory \/>(.*?)<\/Directory>','\n<Directory />'+replace+'</Directory>',result, flags=re.DOTALL)
	helper.write_file(path, replace1)

def fix(path):
	result = helper.read_file(path)
	obj = re.compile(r'[^#]<Directory \/>(.*?)<\/Directory>',re.DOTALL).findall(result)
	if len(obj) != 0:
		if obj[0].find('AllowOverride ') == -1:
			add_allowoverride(path)
		else:
			obj1 = re.compile(r'^\s*AllowOverride (.*?)\n',re.MULTILINE).findall(obj[0])
			if obj1[0] != 'None':
				set_allowoverride(path)
		if obj[0].find('AllowOverrideList') != -1:
			remove_allowoverridelist(path)


# check_override('/etc/apache2/apache123.conf')
# add_allowoverride('/etc/apache2/apache123.conf')
# remove_allowoverridelist('/etc/apache2/apache123.conf')
# set_allowoverride('/etc/apache2/apache123.conf')