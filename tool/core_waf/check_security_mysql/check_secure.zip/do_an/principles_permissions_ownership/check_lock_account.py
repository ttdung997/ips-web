import os

def check():
	print ''
	print ' Lock the Apache User Account '.center(85, '#')
	print ''
	f = os.popen('passwd -S www-data')
	result = f.read().split()
	if result[1] != 'L':
		print '[WARNING] Apache user account is not locked'
	else:
		print '[OK] Apache user account is locked'

def fix():
	f = os.popen('passwd -S www-data')
	result = f.read().split()
	if result[1] != 'L':
		os.system('passwd -l www-data > /dev/null')
	

def unlock():
	os.system('passwd -u www-data')	