import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper

def check():
	print ''
	print ' Restrict Listen Directive '.center(85, '#')
	print ''
	result = helper.read_file('/etc/apache2/ports.conf')
	obj = re.compile(r'^\s*Listen (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):\d+',re.MULTILINE).findall(result)
	obj1 = re.compile(r'^\s*Listen (.+)',re.MULTILINE).findall(result)
	for i in obj:
		if i == '0.0.0.0':
			print '[WARNING] Detect IP address of all zeros'
	if len(obj) != len(obj1):
		print '[WARNING] Detect listen directive with no IP address specified'
	print '[NOTICE] A Listen directive with no IP address specified, or with an IP address of all zeros should not be used'
	print '[NOTICE] Khong ho tro fix tu dong'
# check()

