import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper

def check(path):
	print ''
	print ' Restrict Browser Frame Options '.center(85, '#')
	print ''

	result = helper.read_file(path)
	obj = re.findall(r'(^\s*Header always append X-Frame-Options SAMEORIGIN|Header always append X-Frame-Options DENY)',result, re.MULTILINE)
	if len(obj) == 0:
		print '[WARNING] Header directive for X-Frame-Options config'

def fix(path):
	result = helper.read_file(path)
	obj = re.findall(r'(^\s*Header always append X-Frame-Options SAMEORIGIN|Header always append X-Frame-Options DENY)',result, re.MULTILINE)
	if len(obj) == 0:
		result = helper.read_file(path)
		replace = result + 'Header always append X-Frame-Options SAMEORIGIN\n'
		helper.write_file(path, replace)
	

