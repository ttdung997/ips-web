import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper

def check(path):
	print ''
	print ' Restrict Access to .ht* files '.center(85, '#')
	print ''
	result = helper.read_file(path)
	obj = re.compile(r'[^#]<FilesMatch "\^\\\.ht">(.*?[^#])<\/FilesMatch>',re.DOTALL).findall(result)
	if len(obj) == 0:
		print '[WARNING] FilesMatch directive is not present in the apache configuration'
	else:
		if obj[0][1:-1] != 'Require all denied':
			print '[WARNING] FilesMatch directive is not config to restrict access to any file .ht*'
		else:
			print '[OK] Restrict access to any .ht* file ok'


def fix(path):
	result = helper.read_file(path)
	obj = re.compile(r'[^#]<FilesMatch "\^\\\.ht">(.*?[^#])<\/FilesMatch>',re.DOTALL).findall(result)
	if len(obj) == 0:
		replace = result + '<FilesMatch "^\.ht">\nRequire all denied\n</FilesMatch>\n'
		helper.write_file(path, replace)
	else:
		if obj[0] != 'Require all denied\n':
			replace = re.sub(r'<FilesMatch "\^\\\.ht">(?:.*?[^#])<\/FilesMatch>','',result,flags=re.DOTALL)
			replace1 = replace + '<FilesMatch "^\.ht">\nRequire all denied\n</FilesMatch>\n'
			helper.write_file(path, replace1)

