import os
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper


def check():
	print ''
	print ' Install mod_ssl and/or mod_nss '.center(85, '#')
	print ''
	f = os.popen('apache2ctl -M 2> /dev/null | egrep "ssl|nss"')
	result = f.read()
	f.close()
	if len(result) == 0:
		print '[WARNING] SSL module disable'

def fix():
	os.system('a2enmod ssl > /dev/null')
	os.system('service apache2 restart')


