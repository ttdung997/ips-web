import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper

def check(path):
	print ''
	print ' Ensure SSL Compression is not Enabled '.center(85, '#')
	print ''
	result =helper.read_file(path)
	obj = re.findall(r'^\s*SSLCompression (.+)',result,re.MULTILINE)
	if len(obj) == 0:
		print '[OK] SSLCompression directive is not exsit'
	else:
		if obj[0] != 'off' and obj[0] != 'Off':
			print '[WARNING] SSLCompression must be set to off'

def fix(path):
	result =helper.read_file(path)
	replace = re.sub(r'^\s*SSLCompression .+','SSLCompression off\n',result,flags=re.MULTILINE)
	helper.write_file(path, replace)


