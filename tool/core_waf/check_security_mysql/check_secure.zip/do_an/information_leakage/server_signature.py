import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper

def check(path):
	print ''
	print " Set ServerSignature to 'Off' ".center(85, '#')
	print ''
	result = helper.read_file(path)
	obj = re.compile(r'^\s*ServerSignature (.+)',re.MULTILINE).findall(result)
	if len(obj) == 0:
		print '[WARNING] ServerSignature directive is not exist'
	else:
		if obj[0] != 'Off' and obj[0] != 'off':
			print '[WARNING] ServerSignature has a value incorrect'

def add_directive(path):
	result = helper.read_file(path)
	replace = result + 'ServerSignature Off\n'
	helper.write_file(path, replace)

def set_directive(path):
	result = helper.read_file(path)
	replace = re.sub(r'^\s*ServerSignature (?:.+)','ServerSignature Off\n',result,flags=re.MULTILINE)
	helper.write_file(path, replace)

def fix(path):
	result = helper.read_file(path)
	obj = re.compile(r'^\s*ServerSignature (.+)',re.MULTILINE).findall(result)
	if len(obj) == 0:
		add_directive(path)
	else:
		if obj[0] != 'Off' and obj[0] != 'off':
			set_directive(path)

