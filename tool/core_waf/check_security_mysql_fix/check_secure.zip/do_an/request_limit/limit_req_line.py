import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper


def check(path):
	print ''
	print ' Set the LimitRequestLine directive to 512 or less '.center(85, '#')
	print ''
	result = helper.read_file(path)
	obj = re.findall(r'^\s*LimitRequestline (.+)',result,re.MULTILINE)
	if len(obj) == 0:
		print '[WARNING] LimitRequestline directive is not exsit'
	else:
		if int(obj[0]) > 512:
			print '[WARNING] LimitRequestline too long'

def add_directive(path):
	result = helper.read_file(path)
	replace = result + 'LimitRequestline 512\n'
	helper.write_file(path, replace)

def fix_directive(path):
	result = helper.read_file(path)
	replace = re.sub(r'^\s*LimitRequestline .+','LimitRequestline 512',result,flags=re.MULTILINE)
	helper.write_file(path, replace)

def fix(path):
	result = helper.read_file(path)
	obj = re.findall(r'^\s*LimitRequestline (.+)',result,re.MULTILINE)
	if len(obj) == 0:
		add_directive(path)
	else:
		if int(obj[0]) > 512:
			fix_directive(path)

