import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper

def check(path):
	print ''
	print ' Disable HTTP TRACE Method '.center(85, '#')
	print ''
	result = helper.read_file(path)
	obj = re.compile(r'^\s*TraceEnable (.*?)\n',re.MULTILINE).findall(result)
	if len(obj) != 0:
		if obj[0] != 'off':
			print '[WARNING] The Trace method is enable'
	else:
		print "[WARNING] Can't find TraceEnable directive"

def fix(path):
	result = helper.read_file(path)
	obj = re.compile(r'^\s*TraceEnable (.*?)\n',re.MULTILINE).findall(result)
	if len(obj) != 0:
		if obj[0] != 'off' or obj[0] != 'Off':
			replace = re.sub(r'^\s*TraceEnable (.*?)\n','TraceEnable off\n',result,flags=re.MULTILINE)
			helper.write_file(path, replace)
	else:
		result = result + '\nTraceEnable off\n'
		helper.write_file(path, result)
# fix()
# check()
