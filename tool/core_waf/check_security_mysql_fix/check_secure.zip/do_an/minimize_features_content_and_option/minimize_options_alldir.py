import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper


def check(path):
	print ''
	print ' Minimize Options for Other Directories '.center(85, '#')
	print ''
	result = helper.read_file(path)
	obj = re.compile(r'^\s*Options Includes\s*?\n',re.MULTILINE).findall(result)
	if len(obj) != 0:
		print '[WARNING] Detect Options Includes enable'

def fix(path):
	result = helper.read_file(path)
	obj = re.compile(r'^\s*Options Includes\s*?\n',re.MULTILINE).findall(result)
	if len(obj) != 0:
		replace = re.sub(r'^\s*Options Includes\s*?\n','\tOptions None\n',result, flags=re.MULTILINE)
		helper.write_file(path, replace)

# check_options_includes('/etc/apache2/apache123.conf')
# modify_options('/etc/apache2/apache123.conf')
# fix(helper.config_path)
# check(helper.config_path)