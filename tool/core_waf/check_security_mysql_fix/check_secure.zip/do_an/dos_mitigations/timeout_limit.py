import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper


def check(path):
	print ''
	print ' Set Timeout Limits for Request Headers and Body'.center(85, '#')
	print ''
	f = os.popen("apache2ctl -M 2> /dev/null | grep reqtimeout ")
	result = f.read()
	f.close()
	if len(result) == 0:
		print '[WARNING] mod_requesttimeout disable'
	result = helper.read_file(path)
	obj = re.findall(r'^\s*RequestReadTimeout (.+)',result,re.MULTILINE)
	if len(obj) == 0:
		print '[WARNING] RequestReadTimeout directive is not exsit'
	else:
		if obj[0] != 'header=20-40,MinRate=500 body=20,MinRate=500':
			print '[WARNING] RequestReadTimeout value'

def enable_req_timeout_mod():
	os.system("a2enmod reqtimeout > /dev/null 2> /dev/null")
	os.system("service apache2 restart > /dev/null 2> /dev/null")

def add_directive(path):
	result = helper.read_file(path)
	replace = result + 'RequestReadTimeout header=20-40,MinRate=500 body=20,MinRate=500\n'
	helper.write_file(path, replace)

def fix_directive(path):
	result = helper.read_file(path)
	replace = re.sub(r'^\s*RequestReadTimeout .+','RequestReadTimeout header=20-40,MinRate=500 body=20,MinRate=500\n',result,flags=re.MULTILINE)
	helper.write_file(path,replace)

def fix(path):
	f = os.popen("apache2ctl -M 2> /dev/null | grep requesttimeout")
	result = f.read()
	f.close()
	if len(result) == 0:
		enable_req_timeout_mod()
	result = helper.read_file(path)
	obj = re.findall(r'^\s*RequestReadTimeout (.+)',result,re.MULTILINE)
	if len(obj) == 0:
		add_directive(path)
	else:
		if obj[0] != 'header=20-40,MinRate=500 body=20,MinRate=500':
			fix_directive(path)
# fix(helper.config_path)
# check(helper.config_path)