import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper


def check(path):
	print ''
	print ' Set TimeOut to 10 or less '.center(85, '#')
	print ''
	result = helper.read_file(path)
	obj = re.findall(r'^\s*Timeout (.+)',result,re.MULTILINE)
	if len(obj) == 0:
		print '[WARNING] Timeout directive is not exsit'
	else:
		if int (obj[0]) > 10:
			print '[WARNING] Timeout too long'

def add_directive(path):
	result = helper.read_file(path)
	replace = result + 'Timeout 10\n'
	helper.write_file(path, replace)

def fix_directive(path):
	result = helper.read_file(path)
	replace = re.sub(r'^\s*Timeout .+','Timeout 10\n',result,flags=re.MULTILINE)
	# print replace
	helper.write_file(path, replace)

def fix(path):
	result = helper.read_file(path)
	obj = re.findall(r'^\s*Timeout (.+)',result,re.MULTILINE)
	if len(obj) == 0:
		add_directive(path)
	else:
		if obj[0] > 10:
			fix_directive(path)

# fix(helper.config_path)
# check(helper.config_path)