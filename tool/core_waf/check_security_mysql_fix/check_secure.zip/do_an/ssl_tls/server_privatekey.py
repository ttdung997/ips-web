import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper

def get_dir(path):
	result = helper.read_file(path)
	key = re.findall(r'^\s*SSLCertificateKeyFile (.+)',result,re.MULTILINE)
	tmp = key[0].split('/')
	del tmp[-1]
	a = '/'.join(x for x in tmp)
	return a

def check(path):
	print ''
	print " Protect the Server's Private Key ".center(85, '#')
	print ''
	result = helper.read_file(path)
	cert = re.findall(r'^\s*SSLCertificateFile\s+(.+)',result,re.MULTILINE)
	key = re.findall(r'^\s*SSLCertificateKeyFile (.+)',result,re.MULTILINE)
	if len(cert) == 0 or len(key) == 0:
		print '[WARNING] SSLCertificateFile or SSLCertificateKeyFile not exsit'
	else:
		if  cert[0].split('/')[-2] == key[0].split('/')[-2]:
			print '[WARNING] Key file and cert file in the same directory'
	f = os.popen('ls -la '+ get_dir(path) + ' | grep ".key"')
	result = f.read()
	tmp = result.split('\n')
	for i in range (len(tmp) - 1):
		obj = tmp[i].split()
		if obj[0] != '-r--------' or obj[2] != 'root' or obj[3] != 'root':
			print '[WARNING] Permission of key file ' + obj[-1]

def move_keyfile():
	return 0

def fix(path):
	path_key = get_dir(path)
	f = os.popen("ls "+ path_key + "/ | grep '.key'" )
	result = f.read()
	f.close()
	key = result.split()
	for i in key:
		os.system('chmod 400 ' + path_key + "/" + i)
		os.system('chown root:root ' + path_key + "/" + i)

# check(helper.ssl_config)
# fix(helper.ssl_config)