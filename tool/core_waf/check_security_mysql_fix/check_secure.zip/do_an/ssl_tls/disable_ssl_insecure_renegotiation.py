import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper

def check(path):
	print ''
	print ' Disable SSL Insecure Renegotiation '.center(85, '#')
	print ''
	result =helper.read_file(path)
	obj = re.findall(r'^\s*SSLInsecureRenegotiation (.+)',result,re.MULTILINE)
	if len(obj) == 0:
		print '[OK] SSLInsecureRenegotiation directive is not exsit'
	else:
		if obj[0] != 'off' and obj[0] != 'Off':
			print '[WARNING] SSLInsecureRenegotiation must be set to off'

def fix(path):
	result =helper.read_file(path)
	replace = re.sub(r'^\s*SSLInsecureRenegotiation .+','SSLInsecureRenegotiation off\n',result,flags=re.MULTILINE)
	helper.write_file(path, replace)


