import os
import re
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper


def check():
	print ''
	print ' Check install modsecurity '.center(85, '#')
	print ''
	f = os.popen('apache2ctl -M 2> /dev/null | grep security')
	result = f.read()
	f.close()
	if len(result) == 0:
		print '[WARNING] Modsecurity is not install in apache server'
	print '[NOTICE] See https://www.modsecurity.org/download.html for detail'

# check()