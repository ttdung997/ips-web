import os
import re
import fileinput
import sys
sys.path.insert(0, '/home/anhthc/do_an/')
import helper

def check_mechanism():
	result_check = list()
	f = os.popen("apache2ctl -t -D DUMP_RUN_CFG 2> /dev/null | grep 'Mutex default'")
	result = f.read()
	f.close()
	obj = re.match( r'Mutex default: dir="(.*)" mechanism=(.*)',result)
	lock_dir = obj.group(1)
	mechanism = obj.group(2)[:-1]
	result_check.append(lock_dir)
	result_check.append(mechanism)
	return result_check

def check():
	print ''
	print ' Secure the Lock File '.center(85, '#')
	print ''
	verify = check_mechanism()[0].find(helper.get_DocumentRoot())
	if verify != -1:
		print 'Lock file directory in the Apache DocumentRoot'
	
	f = os.popen("ls -ld " + check_mechanism()[0])
	result = f.read().split()
	f.close()
	if result[2] != 'root':
		print '[WARNING] Ownership of lock file directory is not root'
	if result[3] != 'root':
		print '[WARNING] Group of lock file directory is not root'
	if result[0][8] == 'w':
		print '[WARNING] Lock file directory can write by other user'

	f = os.popen("df -T " + check_mechanism()[0] + " | tail -n +2 | awk '{print $2}'")
	result = f.read()[:-1]
	if result == 'nfs':
		print '[WARNING] Lock file directory is NFS mounted file system'

def fix_permission():
	os.system("chown -R root " + check_mechanism()[0])
	os.system("chgrp -R root " + check_mechanism()[0])
	os.system("chmod -R o-w "+ check_mechanism()[0])

def fix_dir():
	keyword1 = "APACHE_LOCK_DIR"
	replacement1 = "export APACHE_LOCK_DIR=/var/lock/apache2$SUFFIX\n"
	keyword2 = "Mutex file:"
	replacement2 = "Mutex file:${APACHE_LOCK_DIR} default\n"
	for line in fileinput.input('/etc/apache2/envvars', inplace=True):
	    line = line.rstrip()
	    if keyword1 in line:
	        line = line.replace(line, replacement1)
	    # print line
	for line in fileinput.input('/etc/apache2/apache2.conf', inplace=True):
	    line = line.rstrip()
	    if keyword2 in line:
	        line = line.replace(line, replacement2)
	    # print line

def fix():
	verify = check_mechanism()[0].find(helper.get_DocumentRoot())
	if verify != -1:
		fix_dir()
	
	f = os.popen("ls -ld " + check_mechanism()[0])
	result = f.read().split()
	f.close()
	if result[2] != 'root' or result[3] != 'root' or result[0][8] == 'w':
		fix_permission()


