import os
import re
def check_user_and_group_directive(path):
	fu = os.popen("grep -i '^User' " + path)
	fg = os.popen("grep -i '^Group' " + path)
	user = fu.read()
	group = fg.read()
	if len(user) == 0 or user[0] == "#":
		print "[WARNING] User directives not in Apache configuration"
	else:
		print "[OK] Check user directive OK"
	if len(group) == 0 or group[0] == "#":
		print "[WARNING] Group directives not in Apache configuration"
	else:
		print "[OK] Check group directive OK"

def check_UID():
	fuid_min = os.popen("grep '^UID_MIN' /etc/login.defs")
	fuid = os.popen("id www-data")
	
	matchObj_uidmin = re.match(r'UID_MIN\s*(\d*)',fuid_min.read())
	matchObj_uid = re.match(r'uid=(\d*).* gid=(\d*).* groups=(\d*).*',fuid.read())

	UID_MIN = matchObj_uidmin.group(1)
	uid = matchObj_uid.group(1)
	gid = matchObj_uid.group(2)
	groups = matchObj_uid.group(3)
	if int (uid) < int (UID_MIN):
		print "[OK] UID Apache"
	else:
		print "[WARNING] UID Apache is incorrect"

def check_username():
	fuser_name = os.popen("ps -uax | grep apache2 | grep -v '^root'")
	if fuser_name.read().split()[0] == "www-data":
		print "[OK] User Apache"
	else:
		print "[WARNING] User Apache is incorrect"

def check(path):
	print ''
	print ' Run the Apache Web Server as a non-root user '.center(85, '#')
	print ''
	check_user_and_group_directive(path)
	check_UID()
	check_username()


def add_user_and_group():
	os.system("groupadd -r www-data > /dev/null 2> /dev/null")
	os.system("useradd www-data -r -g www-data -d /var/www -s /sbin/nologin > /dev/null 2> /dev/null")

def cf_apache_user_and_group(path):
	f = open(path,'a+')
	f.write("User www-data\nGroup www-data")
	f.close()
	os.system('service apache2 restart > /dev/null 2> /dev/null')

def fix(path):
	add_user_and_group()
	fu = os.popen("grep -i '^User' " + path)
	fg = os.popen("grep -i '^Group' " + path)
	user = fu.read()
	group = fg.read()
	if len(user) == 0 or user[0] == "#" or len(group) == 0 or group[0] == "#":
		cf_apache_user_and_group(path)

