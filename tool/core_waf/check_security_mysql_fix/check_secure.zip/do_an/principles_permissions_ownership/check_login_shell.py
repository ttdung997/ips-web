import os

def check():
	print ''
	print ' Give the Apache User Account an Invalid Shell '.center(85, '#')
	print ''
	with os.popen('grep www-data /etc/passwd') as f:
		for line in f:
			result = line.split(':')
			if result[0] == 'www-data':
				if result[6][:-1] != '/usr/sbin/nologin':
					print "[WARNING] Login shell is not nologin or invalid shell"
				else:
					print "[OK] Login shell"

def fix():
	os.system('chsh -s /usr/sbin/nologin www-data')
